# This is the data for my blog


# License

The following directories and their contents are Copyright Lijia Yu. You may not reuse anything therein without my permission:

* images/

All other directories and files are MIT Licensed. Feel free to use the HTML and CSS as you please. If you do use them, a link back to http://yulijia.github.com would be appreciated, but is not required.
