--- 
published: true
title: 100 things bioinformatics students should do before graduating.
layout: post
categories:
- Bioinformatics

tags: 
- Bioinformatics

---
0000 – Install an Linux system on your computer.

0001 – Follow the [10000 things all ICS students should do before graduating](http://tagide.com/blog/2011/06/things-ics-students-should-do-before-graduating/ "10000 things all ICS students should do before graduating")

0010 – Learn Cell, Molecular Biology, Genomic, Genetics by yourself.

0011 – Learn Computational mathematics, Applied mathematics and Statistics.

0100 – Try create a bioinformatics tool. Belief in your ability.
