--- 
published: true
title: a conference of Genomics and Epigenomics
layout: post
categories:
- Minutes
tags: 
- Genomics
- Epigenomics
- CSH-Asia

---
Last week I attend to the [CSH Asia 2012 conference:High Throughput Biology- Genomics & Epigenomics](http://www.csh-asia.org/system12.html "High Throughput Biology- Genomics & Epigenomics").

This is the first time I go to a such big conference. I also apply to be a volunteer.

On the five days conference, I saw many core-people of this field, such as BingRen, Lucy Shapiro, Sunny Xie , and a lot of young scientists.
they are creative and passionate people. What I learned from them are keep thinking, keep asking, keep working.

On next diary I will show you some interesting works on the conference.


