---
published: true
title: Hello world!
layout: post
author: Yu
category: Uncategorized
tags:

---
Hello world! This site is my first English blog. You can contact me in [this page](http://lijiayu.net/en/guestbook/ "Guestbook").
